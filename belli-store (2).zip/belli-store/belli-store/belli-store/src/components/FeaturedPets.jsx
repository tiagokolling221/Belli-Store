import React from 'react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Heart, Star, Zap, Crown } from 'lucide-react';

const FeaturedPets = () => {
  const featuredPets = [
    {
      id: 1,
      name: "Unicórnio Dourado",
      rarity: "Lendário",
      price: "2000 Robux",
      image: "🦄",
      rarityColor: "bg-yellow-400",
      rarityIcon: Crown,
      description: "Pet ultra raro com habilidades mágicas especiais!"
    },
    {
      id: 2,
      name: "Dragão de Gelo",
      rarity: "Ultra Raro",
      price: "1500 Robux",
      image: "🐉",
      rarityColor: "bg-blue-400",
      rarityIcon: Zap,
      description: "Majestoso dragão com poderes gelados únicos."
    },
    {
      id: 3,
      name: "Gatinho Arco-íris",
      rarity: "Raro",
      price: "800 Robux",
      image: "🌈🐱",
      rarityColor: "bg-purple-400",
      rarityIcon: Star,
      description: "Fofo gatinho com cores vibrantes do arco-íris."
    },
    {
      id: 4,
      name: "Cachorrinho Dourado",
      rarity: "Épico",
      price: "1200 Robux",
      image: "🐕‍🦺",
      rarityColor: "bg-orange-400",
      rarityIcon: Star,
      description: "Leal companheiro com pelagem dourada brilhante."
    },
    {
      id: 5,
      name: "Panda Gigante",
      rarity: "Ultra Raro",
      price: "1800 Robux",
      image: "🐼",
      rarityColor: "bg-green-400",
      rarityIcon: Zap,
      description: "Adorável panda com tamanho impressionante."
    },
    {
      id: 6,
      name: "Coelhinho Rosa",
      rarity: "Comum",
      price: "300 Robux",
      image: "🐰",
      rarityColor: "bg-pink-400",
      rarityIcon: Heart,
      description: "Coelhinho super fofo perfeito para iniciantes."
    }
  ];

  return (
    <section id="featured-pets" className="py-16 bg-white">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-12 fade-in">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            <span className="bg-gradient-to-r from-pink-500 to-purple-500 bg-clip-text text-transparent">
              Pets em Destaque
            </span>
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Descubra os pets mais populares e raros da nossa coleção. 
            Cada um com características únicas e muito amor para dar! 💕
          </p>
        </div>

        {/* Pets Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {featuredPets.map((pet, index) => {
            const RarityIcon = pet.rarityIcon;
            return (
              <div 
                key={pet.id} 
                className="bg-white rounded-2xl shadow-lg border border-gray-100 overflow-hidden hover-lift fade-in group"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                {/* Pet Image */}
                <div className="relative bg-gradient-to-br from-pink-50 to-purple-50 p-8 text-center">
                  <div className="text-6xl mb-4 group-hover:scale-110 transition-transform duration-300">
                    {pet.image}
                  </div>
                  <Badge 
                    className={`${pet.rarityColor} text-white absolute top-4 right-4`}
                  >
                    <RarityIcon className="w-3 h-3 mr-1" />
                    {pet.rarity}
                  </Badge>
                </div>

                {/* Pet Info */}
                <div className="p-6">
                  <h3 className="text-xl font-bold text-gray-800 mb-2">{pet.name}</h3>
                  <p className="text-gray-600 text-sm mb-4">{pet.description}</p>
                  
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-2xl font-bold text-pink-500">{pet.price}</span>
                    <div className="flex items-center text-yellow-400">
                      <Star className="w-4 h-4 fill-current" />
                      <Star className="w-4 h-4 fill-current" />
                      <Star className="w-4 h-4 fill-current" />
                      <Star className="w-4 h-4 fill-current" />
                      <Star className="w-4 h-4 fill-current" />
                    </div>
                  </div>

                  <Button 
                    className="w-full bg-gradient-to-r from-pink-400 to-purple-400 hover:from-pink-500 hover:to-purple-500 text-white"
                  >
                    <Heart className="w-4 h-4 mr-2" />
                    Quero esse!
                  </Button>
                </div>
              </div>
            );
          })}
        </div>

        {/* View All Button */}
        <div className="text-center mt-12 fade-in">
          <Button 
            size="lg" 
            variant="outline" 
            className="border-purple-300 text-purple-600 hover:bg-purple-50 px-8 py-3 text-lg hover-lift"
          >
            Ver Todos os Pets
          </Button>
        </div>
      </div>
    </section>
  );
};

export default FeaturedPets;

