import React from 'react';
import { Search, MessageCircle, Users, Gift } from 'lucide-react';

const HowItWorks = () => {
  const steps = [
    {
      id: 1,
      icon: Search,
      title: "Escolha seu Pet",
      description: "Navegue pela nossa coleção e encontre o pet dos seus sonhos. Filtre por raridade, preço ou tipo!",
      color: "from-pink-400 to-pink-500"
    },
    {
      id: 2,
      icon: MessageCircle,
      title: "Entre em Contato",
      description: "Clique em 'Quero esse!' e fale conosco pelo Discord ou WhatsApp. Nossa equipe está sempre online!",
      color: "from-purple-400 to-purple-500"
    },
    {
      id: 3,
      icon: Users,
      title: "Entre no Servidor",
      description: "Combinamos um horário e você entra no nosso servidor privado do Adopt Me para fazer a troca segura.",
      color: "from-blue-400 to-blue-500"
    },
    {
      id: 4,
      icon: Gift,
      title: "Receba seu Pet",
      description: "Pronto! Seu novo pet está na sua coleção. Aproveite e volte sempre para ver nossas novidades!",
      color: "from-green-400 to-green-500"
    }
  ];

  return (
    <section id="how-it-works" className="py-16 bg-gradient-to-br from-purple-50 via-pink-50 to-blue-50">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-16 fade-in">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            <span className="bg-gradient-to-r from-purple-500 to-pink-500 bg-clip-text text-transparent">
              Como Funciona
            </span>
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Comprar na Belli Store é super fácil e seguro! 
            Siga estes 4 passos simples e tenha seu pet dos sonhos em minutos! ✨
          </p>
        </div>

        {/* Steps */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {steps.map((step, index) => {
            const Icon = step.icon;
            return (
              <div 
                key={step.id} 
                className="relative fade-in"
                style={{ animationDelay: `${index * 200}ms` }}
              >
                {/* Connector Line (hidden on mobile) */}
                {index < steps.length - 1 && (
                  <div className="hidden lg:block absolute top-16 left-full w-full h-0.5 bg-gradient-to-r from-purple-200 to-pink-200 z-0"></div>
                )}
                
                {/* Step Card */}
                <div className="relative bg-white rounded-2xl p-6 shadow-lg border border-gray-100 hover-lift text-center z-10">
                  {/* Step Number */}
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                    <div className={`w-8 h-8 bg-gradient-to-r ${step.color} rounded-full flex items-center justify-center text-white font-bold text-sm`}>
                      {step.id}
                    </div>
                  </div>
                  
                  {/* Icon */}
                  <div className={`w-16 h-16 bg-gradient-to-r ${step.color} rounded-2xl flex items-center justify-center mx-auto mb-4 mt-4`}>
                    <Icon className="w-8 h-8 text-white" />
                  </div>
                  
                  {/* Content */}
                  <h3 className="text-xl font-bold text-gray-800 mb-3">{step.title}</h3>
                  <p className="text-gray-600 text-sm leading-relaxed">{step.description}</p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Trust Indicators */}
        <div className="mt-16 fade-in">
          <div className="bg-white rounded-2xl p-8 shadow-lg border border-gray-100">
            <div className="text-center mb-8">
              <h3 className="text-2xl font-bold text-gray-800 mb-2">Por que escolher a Belli Store?</h3>
              <p className="text-gray-600">Sua segurança e satisfação são nossa prioridade!</p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="text-center">
                <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl">🛡️</span>
                </div>
                <h4 className="font-semibold text-gray-800 mb-2">100% Seguro</h4>
                <p className="text-sm text-gray-600">Todas as trocas são feitas em servidores privados com moderação ativa.</p>
              </div>
              
              <div className="text-center">
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl">⚡</span>
                </div>
                <h4 className="font-semibold text-gray-800 mb-2">Entrega Rápida</h4>
                <p className="text-sm text-gray-600">Receba seu pet em minutos! Nossa equipe está sempre online.</p>
              </div>
              
              <div className="text-center">
                <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl">💝</span>
                </div>
                <h4 className="font-semibold text-gray-800 mb-2">Suporte Carinhoso</h4>
                <p className="text-sm text-gray-600">Atendimento humanizado e carinhoso para todas as idades.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HowItWorks;

