import React, { useState } from 'react';
import { Menu, X, User, ShoppingBag, Heart } from 'lucide-react';
import { Button } from './ui/button';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-sm border-b border-pink-100 shadow-sm">
      <div className="container mx-auto px-4 py-3">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <div className="flex items-center space-x-2">
            <div className="w-10 h-10 bg-gradient-to-br from-pink-300 to-purple-300 rounded-full flex items-center justify-center">
              <Heart className="w-6 h-6 text-white" />
            </div>
            <h1 className="logo text-2xl font-bold bg-gradient-to-r from-pink-500 to-purple-500 bg-clip-text text-transparent">
              Belli Store
            </h1>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <a href="#home" className="text-gray-700 hover:text-pink-500 transition-colors font-medium">
              Início
            </a>
            <a href="#products" className="text-gray-700 hover:text-pink-500 transition-colors font-medium">
              Produtos
            </a>
            <a href="#how-to-buy" className="text-gray-700 hover:text-pink-500 transition-colors font-medium">
              Como Comprar
            </a>
            <a href="#contact" className="text-gray-700 hover:text-pink-500 transition-colors font-medium">
              Contato
            </a>
          </nav>

          {/* Desktop Actions */}
          <div className="hidden md:flex items-center space-x-4">
            <Button variant="ghost" size="sm" className="text-gray-700 hover:text-pink-500">
              <ShoppingBag className="w-4 h-4 mr-2" />
              Carrinho
            </Button>
            <Button className="bg-gradient-to-r from-pink-400 to-purple-400 hover:from-pink-500 hover:to-purple-500 text-white">
              <User className="w-4 h-4 mr-2" />
              Entrar
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={toggleMenu}
            className="md:hidden p-2 text-gray-700 hover:text-pink-500 transition-colors"
          >
            {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden mt-4 pb-4 border-t border-pink-100">
            <nav className="flex flex-col space-y-4 mt-4">
              <a
                href="#home"
                className="text-gray-700 hover:text-pink-500 transition-colors font-medium py-2"
                onClick={() => setIsMenuOpen(false)}
              >
                Início
              </a>
              <a
                href="#products"
                className="text-gray-700 hover:text-pink-500 transition-colors font-medium py-2"
                onClick={() => setIsMenuOpen(false)}
              >
                Produtos
              </a>
              <a
                href="#how-to-buy"
                className="text-gray-700 hover:text-pink-500 transition-colors font-medium py-2"
                onClick={() => setIsMenuOpen(false)}
              >
                Como Comprar
              </a>
              <a
                href="#contact"
                className="text-gray-700 hover:text-pink-500 transition-colors font-medium py-2"
                onClick={() => setIsMenuOpen(false)}
              >
                Contato
              </a>
              <div className="flex flex-col space-y-2 pt-4 border-t border-pink-100">
                <Button variant="ghost" size="sm" className="justify-start text-gray-700 hover:text-pink-500">
                  <ShoppingBag className="w-4 h-4 mr-2" />
                  Carrinho
                </Button>
                <Button className="bg-gradient-to-r from-pink-400 to-purple-400 hover:from-pink-500 hover:to-purple-500 text-white justify-start">
                  <User className="w-4 h-4 mr-2" />
                  Entrar
                </Button>
              </div>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
};

export default Header;

