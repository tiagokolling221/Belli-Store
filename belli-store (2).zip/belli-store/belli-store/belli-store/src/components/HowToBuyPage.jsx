import React from 'react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Search, MessageCircle, Users, Gift, Shield, Zap, Heart, Star, CheckCircle } from 'lucide-react';

const HowToBuyPage = () => {
  const steps = [
    {
      id: 1,
      icon: Search,
      title: "Escolha seu Pet",
      description: "Navegue pela nossa coleção incrível de pets do Adopt Me. Use os filtros para encontrar exatamente o que você procura!",
      details: [
        "Filtre por raridade (Comum, Raro, Épico, Ultra Raro, Lendário)",
        "Use a busca para encontrar pets específicos",
        "Veja fotos, descrições e preços detalhados",
        "Compare diferentes opções antes de decidir"
      ],
      color: "from-pink-400 to-pink-500",
      bgColor: "bg-pink-50"
    },
    {
      id: 2,
      icon: MessageCircle,
      title: "Entre em Contato",
      description: "Clique em 'Quero esse!' e fale conosco pelo Discord ou WhatsApp. Nossa equipe carinhosa está sempre pronta para ajudar!",
      details: [
        "Discord: BelliStore#1234 (resposta em minutos)",
        "WhatsApp: +55 (11) 99999-9999",
        "Informe qual pet você quer e tire suas dúvidas",
        "Negociamos preços especiais para compras múltiplas"
      ],
      color: "from-purple-400 to-purple-500",
      bgColor: "bg-purple-50"
    },
    {
      id: 3,
      icon: Users,
      title: "Combinamos a Troca",
      description: "Marcamos um horário que funcione para você e entramos juntos no nosso servidor privado do Adopt Me.",
      details: [
        "Servidor privado com moderação ativa 24/7",
        "Ambiente seguro e controlado para trocas",
        "Flexibilidade de horários (9h às 22h)",
        "Suporte durante todo o processo"
      ],
      color: "from-blue-400 to-blue-500",
      bgColor: "bg-blue-50"
    },
    {
      id: 4,
      icon: Gift,
      title: "Receba seu Pet",
      description: "Pronto! Seu novo pet está na sua coleção. Aproveite e volte sempre para ver nossas novidades incríveis!",
      details: [
        "Troca instantânea e segura",
        "Verificação de que tudo ocorreu corretamente",
        "Suporte pós-venda se precisar de ajuda",
        "Desconto especial na próxima compra"
      ],
      color: "from-green-400 to-green-500",
      bgColor: "bg-green-50"
    }
  ];

  const safetyFeatures = [
    {
      icon: Shield,
      title: "100% Seguro",
      description: "Todas as trocas são feitas em servidores privados com moderação ativa.",
      color: "text-green-500"
    },
    {
      icon: Zap,
      title: "Entrega Rápida",
      description: "Receba seu pet em minutos! Nossa equipe está sempre online.",
      color: "text-blue-500"
    },
    {
      icon: Heart,
      title: "Suporte Carinhoso",
      description: "Atendimento humanizado e carinhoso para todas as idades.",
      color: "text-pink-500"
    }
  ];

  const testimonials = [
    {
      id: 1,
      name: "Mariana",
      age: 13,
      rating: 5,
      comment: "Comprei meu primeiro pet lendário aqui! O processo foi super fácil e a equipe me explicou tudo direitinho. Agora sou cliente fiel! 🦄✨",
      avatar: "👧",
      pet: "Unicórnio Dourado"
    },
    {
      id: 2,
      name: "Gabriel",
      age: 15,
      rating: 5,
      comment: "Já fiz mais de 10 compras na Belli Store. Sempre rápido, seguro e com preços justos. Recomendo para todos os meus amigos! 🐾",
      avatar: "👦",
      pet: "Coleção Completa"
    },
    {
      id: 3,
      name: "Isabella",
      age: 11,
      rating: 5,
      comment: "Minha mãe ficou preocupada no início, mas viu como é seguro e agora ela mesma me ajuda a escolher os pets! Obrigada Belli Store! 💕",
      avatar: "👧",
      pet: "Dragão de Gelo"
    },
    {
      id: 4,
      name: "Lucas",
      age: 14,
      rating: 5,
      comment: "O atendimento é incrível! Eles me ajudaram a montar a coleção dos meus sonhos e ainda ganhei desconto. Melhor loja ever! 🎮",
      avatar: "👦",
      pet: "Leão Real"
    }
  ];

  const faqs = [
    {
      question: "É realmente seguro comprar pets online?",
      answer: "Sim! Usamos apenas servidores privados com moderação ativa. Nunca pedimos senhas ou informações pessoais. A troca é feita diretamente no jogo, de forma transparente."
    },
    {
      question: "Quanto tempo demora para receber meu pet?",
      answer: "Normalmente entre 5 a 30 minutos! Dependemos apenas de você estar online e disponível para entrar no servidor. Nossa equipe está sempre pronta."
    },
    {
      question: "Posso trocar um pet que não gostei?",
      answer: "Claro! Temos política de troca em até 24h se você não ficou satisfeito. Queremos que você seja feliz com sua compra!"
    },
    {
      question: "Vocês aceitam pets como forma de pagamento?",
      answer: "Sim! Aceitamos pets raros como parte do pagamento. Nossa equipe avalia o valor justo e faz a negociação com você."
    }
  ];

  return (
    <section id="how-to-buy" className="py-16 bg-gradient-to-br from-purple-50 via-pink-50 to-blue-50">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-16 fade-in">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            <span className="bg-gradient-to-r from-purple-500 to-pink-500 bg-clip-text text-transparent">
              Como Comprar
            </span>
          </h1>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Comprar na Belli Store é super fácil, rápido e 100% seguro! 
            Siga nosso guia passo a passo e tenha seu pet dos sonhos em minutos! ✨
          </p>
        </div>

        {/* Detailed Steps */}
        <div className="space-y-12 mb-16">
          {steps.map((step, index) => {
            const Icon = step.icon;
            return (
              <div 
                key={step.id} 
                className={`fade-in ${index % 2 === 0 ? 'lg:flex-row' : 'lg:flex-row-reverse'} flex flex-col lg:flex items-center gap-8`}
                style={{ animationDelay: `${index * 200}ms` }}
              >
                {/* Step Content */}
                <div className="flex-1">
                  <div className={`${step.bgColor} rounded-2xl p-8 shadow-lg border border-gray-100`}>
                    <div className="flex items-center mb-4">
                      <div className={`w-12 h-12 bg-gradient-to-r ${step.color} rounded-2xl flex items-center justify-center mr-4`}>
                        <Icon className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <Badge className={`bg-gradient-to-r ${step.color} text-white mb-2`}>
                          Passo {step.id}
                        </Badge>
                        <h3 className="text-2xl font-bold text-gray-800">{step.title}</h3>
                      </div>
                    </div>
                    
                    <p className="text-gray-600 mb-6 text-lg">{step.description}</p>
                    
                    <ul className="space-y-3">
                      {step.details.map((detail, i) => (
                        <li key={i} className="flex items-start">
                          <CheckCircle className="w-5 h-5 text-green-500 mr-3 mt-0.5 flex-shrink-0" />
                          <span className="text-gray-700">{detail}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                {/* Step Illustration */}
                <div className="flex-1 text-center">
                  <div className="relative">
                    <div className={`w-64 h-64 bg-gradient-to-br ${step.color} rounded-full mx-auto flex items-center justify-center shadow-2xl`}>
                      <Icon className="w-24 h-24 text-white" />
                    </div>
                    <div className="absolute -top-4 -right-4 w-16 h-16 bg-yellow-400 rounded-full flex items-center justify-center text-2xl animate-bounce">
                      {step.id === 1 && '🔍'}
                      {step.id === 2 && '💬'}
                      {step.id === 3 && '🤝'}
                      {step.id === 4 && '🎉'}
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Safety Features */}
        <div className="mb-16 fade-in">
          <h2 className="text-3xl font-bold text-center mb-8">
            <span className="bg-gradient-to-r from-green-500 to-blue-500 bg-clip-text text-transparent">
              Por que somos a escolha mais segura?
            </span>
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {safetyFeatures.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <div 
                  key={index}
                  className="bg-white rounded-2xl p-6 shadow-lg border border-gray-100 text-center hover-lift fade-in"
                  style={{ animationDelay: `${index * 100}ms` }}
                >
                  <div className={`w-16 h-16 ${feature.color} bg-gray-100 rounded-2xl flex items-center justify-center mx-auto mb-4`}>
                    <Icon className="w-8 h-8" />
                  </div>
                  <h3 className="text-xl font-bold text-gray-800 mb-3">{feature.title}</h3>
                  <p className="text-gray-600">{feature.description}</p>
                </div>
              );
            })}
          </div>
        </div>

        {/* Testimonials */}
        <div className="mb-16 fade-in">
          <h2 className="text-3xl font-bold text-center mb-8">
            <span className="bg-gradient-to-r from-pink-500 to-purple-500 bg-clip-text text-transparent">
              Histórias de Sucesso
            </span>
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {testimonials.map((testimonial, index) => (
              <div 
                key={testimonial.id}
                className="bg-white rounded-2xl p-6 shadow-lg border border-gray-100 hover-lift fade-in"
                style={{ animationDelay: `${index * 150}ms` }}
              >
                <div className="flex items-center mb-4">
                  <div className="text-4xl mr-4">{testimonial.avatar}</div>
                  <div>
                    <h4 className="font-bold text-gray-800">{testimonial.name}</h4>
                    <p className="text-sm text-gray-600">{testimonial.age} anos</p>
                    <Badge className="bg-purple-100 text-purple-600 text-xs mt-1">
                      Comprou: {testimonial.pet}
                    </Badge>
                  </div>
                </div>
                
                <div className="flex items-center mb-3">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 text-yellow-400 fill-current" />
                  ))}
                </div>
                
                <p className="text-gray-600 italic">"{testimonial.comment}"</p>
              </div>
            ))}
          </div>
        </div>

        {/* FAQ */}
        <div className="fade-in">
          <h2 className="text-3xl font-bold text-center mb-8">
            <span className="bg-gradient-to-r from-blue-500 to-purple-500 bg-clip-text text-transparent">
              Perguntas Frequentes
            </span>
          </h2>
          
          <div className="max-w-3xl mx-auto space-y-4">
            {faqs.map((faq, index) => (
              <div 
                key={index}
                className="bg-white rounded-2xl p-6 shadow-lg border border-gray-100 fade-in"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <h3 className="text-lg font-bold text-gray-800 mb-3">{faq.question}</h3>
                <p className="text-gray-600">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>

        {/* CTA */}
        <div className="text-center mt-16 fade-in">
          <div className="bg-gradient-to-r from-pink-400 to-purple-400 rounded-2xl p-8 text-white">
            <h3 className="text-2xl font-bold mb-4">Pronto para começar?</h3>
            <p className="text-lg mb-6 opacity-90">
              Junte-se a mais de 1000 clientes felizes e encontre seu pet dos sonhos hoje mesmo!
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                size="lg" 
                className="bg-white text-purple-600 hover:bg-gray-100 px-8 py-3 text-lg hover-lift"
              >
                <Heart className="w-5 h-5 mr-2" />
                Ver Pets Disponíveis
              </Button>
              <Button 
                variant="outline" 
                size="lg" 
                className="border-white text-white hover:bg-white hover:text-purple-600 px-8 py-3 text-lg hover-lift"
              >
                <MessageCircle className="w-5 h-5 mr-2" />
                Falar no WhatsApp
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HowToBuyPage;

