import React, { useState } from 'react';
import Header from './Header';
import Hero from './Hero';
import FeaturedPets from './FeaturedPets';
import HowItWorks from './HowItWorks';
import ProductsPage from './ProductsPage';
import HowToBuyPage from './HowToBuyPage';
import ContactPage from './ContactPage';
import Footer from './Footer';

const Navigation = () => {
  const [currentPage, setCurrentPage] = useState('home');

  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return (
          <>
            <Hero />
            <FeaturedPets />
            <HowItWorks />
          </>
        );
      case 'products':
        return <ProductsPage />;
      case 'how-to-buy':
        return <HowToBuyPage />;
      case 'contact':
        return <ContactPage />;
      default:
        return (
          <>
            <Hero />
            <FeaturedPets />
            <HowItWorks />
          </>
        );
    }
  };

  // Interceptar cliques nos links de navegação
  React.useEffect(() => {
    const handleNavigation = (e) => {
      const target = e.target.closest('a');
      if (target && target.getAttribute('href')?.startsWith('#')) {
        e.preventDefault();
        const page = target.getAttribute('href').substring(1);
        setCurrentPage(page);
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }
    };

    document.addEventListener('click', handleNavigation);
    return () => document.removeEventListener('click', handleNavigation);
  }, []);

  return (
    <div className="min-h-screen">
      <Header />
      <main>
        {renderPage()}
      </main>
      <Footer />
    </div>
  );
};

export default Navigation;

