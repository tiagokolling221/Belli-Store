import React from 'react';
import { Button } from './ui/button';
import { Sparkles, Star, Heart } from 'lucide-react';
import adoptMePetsImage from '../assets/adopt_me_pets_figures.jpg';

const Hero = () => {
  return (
    <section id="home" className="pt-20 pb-16 bg-gradient-to-br from-pink-50 via-purple-50 to-blue-50 overflow-hidden">
      <div className="container mx-auto px-4">
        <div className="flex flex-col lg:flex-row items-center justify-between gap-12">
          {/* Content */}
          <div className="flex-1 text-center lg:text-left fade-in">
            <div className="flex items-center justify-center lg:justify-start mb-4">
              <Sparkles className="w-6 h-6 text-yellow-400 mr-2" />
              <span className="text-purple-600 font-semibold">A lojinha mais fofa do Roblox!</span>
              <Sparkles className="w-6 h-6 text-yellow-400 ml-2" />
            </div>
            
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 leading-tight">
              <span className="bg-gradient-to-r from-pink-500 via-purple-500 to-blue-500 bg-clip-text text-transparent">
                Belli Store
              </span>
              <br />
              <span className="text-gray-800">chegou!</span>
            </h1>
            
            <p className="text-lg md:text-xl text-gray-600 mb-8 max-w-2xl mx-auto lg:mx-0">
              Encontre os pets mais fofos e raros do Adopt Me! Negociações seguras, 
              preços justos e atendimento carinhoso. Sua coleção dos sonhos está aqui! 🐾
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <Button 
                size="lg" 
                className="bg-gradient-to-r from-pink-400 to-purple-400 hover:from-pink-500 hover:to-purple-500 text-white px-8 py-3 text-lg hover-lift"
              >
                <Heart className="w-5 h-5 mr-2" />
                Ver Pets Disponíveis
              </Button>
              <Button 
                variant="outline" 
                size="lg" 
                className="border-purple-300 text-purple-600 hover:bg-purple-50 px-8 py-3 text-lg hover-lift"
              >
                <Star className="w-5 h-5 mr-2" />
                Como Funciona
              </Button>
            </div>
            
            {/* Stats */}
            <div className="flex flex-wrap justify-center lg:justify-start gap-8 mt-12">
              <div className="text-center">
                <div className="text-2xl font-bold text-pink-500">500+</div>
                <div className="text-sm text-gray-600">Pets Disponíveis</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-purple-500">1000+</div>
                <div className="text-sm text-gray-600">Clientes Felizes</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-blue-500">100%</div>
                <div className="text-sm text-gray-600">Seguro</div>
              </div>
            </div>
          </div>
          
          {/* Image */}
          <div className="flex-1 relative fade-in">
            <div className="relative">
              {/* Decorative elements */}
              <div className="absolute -top-4 -left-4 w-20 h-20 bg-yellow-200 rounded-full opacity-60 animate-pulse"></div>
              <div className="absolute -bottom-4 -right-4 w-16 h-16 bg-pink-200 rounded-full opacity-60 animate-pulse delay-1000"></div>
              <div className="absolute top-1/2 -right-8 w-12 h-12 bg-purple-200 rounded-full opacity-60 animate-pulse delay-500"></div>
              
              {/* Main image */}
              <div className="relative bg-white rounded-3xl shadow-2xl p-6 hover-lift">
                <img 
                  src={adoptMePetsImage} 
                  alt="Pets fofos do Adopt Me" 
                  className="w-full h-auto rounded-2xl"
                />
                <div className="absolute top-4 right-4 bg-yellow-400 text-yellow-900 px-3 py-1 rounded-full text-sm font-semibold">
                  ✨ Novos Pets!
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Floating elements */}
      <div className="absolute top-20 left-10 text-4xl animate-bounce delay-300">🐶</div>
      <div className="absolute top-40 right-20 text-3xl animate-bounce delay-700">🐱</div>
      <div className="absolute bottom-20 left-20 text-3xl animate-bounce delay-1000">🦄</div>
    </section>
  );
};

export default Hero;

