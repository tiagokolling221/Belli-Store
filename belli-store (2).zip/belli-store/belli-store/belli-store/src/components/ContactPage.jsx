import React, { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { MessageCircle, Mail, MapPin, Clock, Send, Heart, Star } from 'lucide-react';

const ContactPage = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: ''
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Aqui seria implementada a lógica de envio do formulário
    alert('Mensagem enviada! Entraremos em contato em breve! 💕');
    setFormData({ name: '', email: '', message: '' });
  };

  const testimonials = [
    {
      id: 1,
      name: "Ana Clara",
      age: 12,
      rating: 5,
      comment: "Comprei meu unicórnio dourado aqui e foi super rápido! A equipe é muito fofa e me ajudou com tudo! 🦄💕",
      avatar: "👧"
    },
    {
      id: 2,
      name: "Pedro",
      age: 14,
      rating: 5,
      comment: "Melhor loja de pets do Adopt Me! Preços justos e atendimento incrível. Já comprei 5 pets aqui! 🐾",
      avatar: "👦"
    },
    {
      id: 3,
      name: "Sofia",
      age: 10,
      rating: 5,
      comment: "Minha mãe me ajudou a comprar um dragão de gelo e foi tudo perfeito! Super recomendo! ❄️🐉",
      avatar: "👧"
    }
  ];

  return (
    <section id="contact" className="py-16 bg-white">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-12 fade-in">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            <span className="bg-gradient-to-r from-pink-500 to-purple-500 bg-clip-text text-transparent">
              Entre em Contato
            </span>
          </h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Tem dúvidas? Quer negociar um pet especial? Nossa equipe carinhosa está aqui para ajudar! 
            Fale conosco e faça parte da família Belli Store! 💕
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Contact Form */}
          <div className="fade-in">
            <div className="bg-gradient-to-br from-pink-50 to-purple-50 rounded-2xl p-8 shadow-lg border border-gray-100">
              <h2 className="text-2xl font-bold text-gray-800 mb-6 flex items-center">
                <Mail className="w-6 h-6 mr-3 text-pink-500" />
                Envie uma Mensagem
              </h2>
              
              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-2">
                    Seu Nome
                  </label>
                  <Input
                    type="text"
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleInputChange}
                    placeholder="Como você gostaria de ser chamado?"
                    required
                    className="w-full border-purple-200 focus:border-purple-400"
                  />
                </div>
                
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">
                    Seu E-mail
                  </label>
                  <Input
                    type="email"
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    placeholder="seu.email@exemplo.com"
                    required
                    className="w-full border-purple-200 focus:border-purple-400"
                  />
                </div>
                
                <div>
                  <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-2">
                    Sua Mensagem
                  </label>
                  <Textarea
                    id="message"
                    name="message"
                    value={formData.message}
                    onChange={handleInputChange}
                    placeholder="Conte-nos qual pet você está procurando ou tire suas dúvidas..."
                    rows={5}
                    required
                    className="w-full border-purple-200 focus:border-purple-400 resize-none"
                  />
                </div>
                
                <Button 
                  type="submit"
                  className="w-full bg-gradient-to-r from-pink-400 to-purple-400 hover:from-pink-500 hover:to-purple-500 text-white py-3"
                >
                  <Send className="w-5 h-5 mr-2" />
                  Enviar Mensagem
                </Button>
              </form>
            </div>
          </div>

          {/* Contact Info */}
          <div className="fade-in">
            <div className="space-y-8">
              {/* Direct Contact */}
              <div className="bg-white rounded-2xl p-6 shadow-lg border border-gray-100">
                <h3 className="text-xl font-bold text-gray-800 mb-4">Contato Direto</h3>
                <div className="space-y-4">
                  <div className="flex items-center space-x-4 p-4 bg-purple-50 rounded-xl">
                    <div className="w-12 h-12 bg-purple-500 rounded-full flex items-center justify-center">
                      <MessageCircle className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <p className="font-semibold text-gray-800">Discord</p>
                      <p className="text-purple-600">BelliStore#1234</p>
                      <p className="text-sm text-gray-600">Resposta em minutos!</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-4 p-4 bg-green-50 rounded-xl">
                    <div className="w-12 h-12 bg-green-500 rounded-full flex items-center justify-center">
                      <span className="text-white text-xl">📱</span>
                    </div>
                    <div>
                      <p className="font-semibold text-gray-800">WhatsApp</p>
                      <p className="text-green-600">+55 (11) 99999-9999</p>
                      <p className="text-sm text-gray-600">Online das 9h às 22h</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-4 p-4 bg-blue-50 rounded-xl">
                    <div className="w-12 h-12 bg-blue-500 rounded-full flex items-center justify-center">
                      <Mail className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <p className="font-semibold text-gray-800">E-mail</p>
                      <p className="text-blue-600">contato@bellistore.com</p>
                      <p className="text-sm text-gray-600">Resposta em até 24h</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Business Hours */}
              <div className="bg-white rounded-2xl p-6 shadow-lg border border-gray-100">
                <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center">
                  <Clock className="w-5 h-5 mr-2 text-pink-500" />
                  Horário de Atendimento
                </h3>
                <div className="space-y-2 text-gray-600">
                  <div className="flex justify-between">
                    <span>Segunda a Sexta:</span>
                    <span className="font-semibold">9h às 22h</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Sábado e Domingo:</span>
                    <span className="font-semibold">10h às 20h</span>
                  </div>
                  <p className="text-sm text-purple-600 mt-3">
                    * Horário de Brasília (GMT-3)
                  </p>
                </div>
              </div>

              {/* Belli World Map */}
              <div className="bg-gradient-to-br from-pink-100 to-purple-100 rounded-2xl p-6 shadow-lg border border-gray-100">
                <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center">
                  <MapPin className="w-5 h-5 mr-2 text-pink-500" />
                  Belli World
                </h3>
                <div className="text-center">
                  <div className="text-6xl mb-4">🏰</div>
                  <p className="text-gray-600 mb-4">
                    Nosso castelo mágico no mundo dos pets! 
                    Venha nos visitar no servidor privado para trocas seguras.
                  </p>
                  <Button className="bg-gradient-to-r from-pink-400 to-purple-400 hover:from-pink-500 hover:to-purple-500 text-white">
                    <Heart className="w-4 h-4 mr-2" />
                    Visitar Belli World
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Testimonials */}
        <div className="mt-16 fade-in">
          <h2 className="text-3xl font-bold text-center mb-8">
            <span className="bg-gradient-to-r from-pink-500 to-purple-500 bg-clip-text text-transparent">
              O que nossos clientes dizem
            </span>
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {testimonials.map((testimonial, index) => (
              <div 
                key={testimonial.id}
                className="bg-white rounded-2xl p-6 shadow-lg border border-gray-100 hover-lift fade-in"
                style={{ animationDelay: `${index * 200}ms` }}
              >
                <div className="flex items-center mb-4">
                  <div className="text-3xl mr-3">{testimonial.avatar}</div>
                  <div>
                    <h4 className="font-semibold text-gray-800">{testimonial.name}</h4>
                    <p className="text-sm text-gray-600">{testimonial.age} anos</p>
                  </div>
                </div>
                
                <div className="flex items-center mb-3">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 text-yellow-400 fill-current" />
                  ))}
                </div>
                
                <p className="text-gray-600 text-sm italic">"{testimonial.comment}"</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactPage;

