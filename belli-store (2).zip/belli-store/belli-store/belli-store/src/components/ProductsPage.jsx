import React, { useState } from 'react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Input } from './ui/input';
import { Heart, Star, Crown, Zap, Filter, Search } from 'lucide-react';

const ProductsPage = () => {
  const [selectedRarity, setSelectedRarity] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');

  const allPets = [
    {
      id: 1,
      name: "Unicórnio Dourado",
      rarity: "Lendário",
      price: "2000 Robux",
      image: "🦄",
      rarityColor: "bg-yellow-400",
      rarityIcon: Crown,
      description: "Pet ultra raro com habilidades mágicas especiais!",
      category: "lendario"
    },
    {
      id: 2,
      name: "Dragão de Gelo",
      rarity: "Ultra Raro",
      price: "1500 Robux",
      image: "🐉",
      rarityColor: "bg-blue-400",
      rarityIcon: Zap,
      description: "Majestoso dragão com poderes gelados únicos.",
      category: "ultra-raro"
    },
    {
      id: 3,
      name: "Gatinho Arco-íris",
      rarity: "Raro",
      price: "800 Robux",
      image: "🌈🐱",
      rarityColor: "bg-purple-400",
      rarityIcon: Star,
      description: "Fofo gatinho com cores vibrantes do arco-íris.",
      category: "raro"
    },
    {
      id: 4,
      name: "Cachorrinho Dourado",
      rarity: "Épico",
      price: "1200 Robux",
      image: "🐕‍🦺",
      rarityColor: "bg-orange-400",
      rarityIcon: Star,
      description: "Leal companheiro com pelagem dourada brilhante.",
      category: "epico"
    },
    {
      id: 5,
      name: "Panda Gigante",
      rarity: "Ultra Raro",
      price: "1800 Robux",
      image: "🐼",
      rarityColor: "bg-green-400",
      rarityIcon: Zap,
      description: "Adorável panda com tamanho impressionante.",
      category: "ultra-raro"
    },
    {
      id: 6,
      name: "Coelhinho Rosa",
      rarity: "Comum",
      price: "300 Robux",
      image: "🐰",
      rarityColor: "bg-pink-400",
      rarityIcon: Heart,
      description: "Coelhinho super fofo perfeito para iniciantes.",
      category: "comum"
    },
    {
      id: 7,
      name: "Leão Real",
      rarity: "Lendário",
      price: "2500 Robux",
      image: "🦁",
      rarityColor: "bg-yellow-400",
      rarityIcon: Crown,
      description: "Majestoso rei da selva com coroa dourada.",
      category: "lendario"
    },
    {
      id: 8,
      name: "Gato Ninja",
      rarity: "Épico",
      price: "1100 Robux",
      image: "🥷🐱",
      rarityColor: "bg-gray-600",
      rarityIcon: Star,
      description: "Gato misterioso com habilidades ninja.",
      category: "epico"
    },
    {
      id: 9,
      name: "Peixinho Dourado",
      rarity: "Raro",
      price: "600 Robux",
      image: "🐠",
      rarityColor: "bg-blue-400",
      rarityIcon: Star,
      description: "Peixinho brilhante que traz sorte.",
      category: "raro"
    },
    {
      id: 10,
      name: "Hamster Fofo",
      rarity: "Comum",
      price: "200 Robux",
      image: "🐹",
      rarityColor: "bg-brown-400",
      rarityIcon: Heart,
      description: "Pequeno hamster cheio de energia.",
      category: "comum"
    },
    {
      id: 11,
      name: "Águia Dourada",
      rarity: "Ultra Raro",
      price: "1700 Robux",
      image: "🦅",
      rarityColor: "bg-yellow-600",
      rarityIcon: Zap,
      description: "Majestosa águia com asas douradas.",
      category: "ultra-raro"
    },
    {
      id: 12,
      name: "Tartaruga Sábia",
      rarity: "Épico",
      price: "900 Robux",
      image: "🐢",
      rarityColor: "bg-green-600",
      rarityIcon: Star,
      description: "Tartaruga antiga com muita sabedoria.",
      category: "epico"
    }
  ];

  const rarityFilters = [
    { id: 'all', label: 'Todos', count: allPets.length },
    { id: 'comum', label: 'Comum', count: allPets.filter(p => p.category === 'comum').length },
    { id: 'raro', label: 'Raro', count: allPets.filter(p => p.category === 'raro').length },
    { id: 'epico', label: 'Épico', count: allPets.filter(p => p.category === 'epico').length },
    { id: 'ultra-raro', label: 'Ultra Raro', count: allPets.filter(p => p.category === 'ultra-raro').length },
    { id: 'lendario', label: 'Lendário', count: allPets.filter(p => p.category === 'lendario').length }
  ];

  const filteredPets = allPets.filter(pet => {
    const matchesRarity = selectedRarity === 'all' || pet.category === selectedRarity;
    const matchesSearch = pet.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         pet.description.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesRarity && matchesSearch;
  });

  return (
    <section id="products" className="py-16 bg-gradient-to-br from-pink-50 via-purple-50 to-blue-50 min-h-screen">
      <div className="container mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-12 fade-in">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            <span className="bg-gradient-to-r from-pink-500 to-purple-500 bg-clip-text text-transparent">
              Nossos Pets
            </span>
          </h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Explore nossa incrível coleção de pets do Adopt Me! 
            Filtre por raridade e encontre seu companheiro perfeito! 🐾
          </p>
        </div>

        {/* Search and Filters */}
        <div className="mb-8 fade-in">
          {/* Search Bar */}
          <div className="relative mb-6 max-w-md mx-auto">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <Input
              type="text"
              placeholder="Buscar pets..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 pr-4 py-3 w-full rounded-full border-2 border-purple-200 focus:border-purple-400"
            />
          </div>

          {/* Rarity Filters */}
          <div className="flex flex-wrap justify-center gap-3">
            {rarityFilters.map((filter) => (
              <Button
                key={filter.id}
                variant={selectedRarity === filter.id ? "default" : "outline"}
                onClick={() => setSelectedRarity(filter.id)}
                className={`rounded-full px-6 py-2 ${
                  selectedRarity === filter.id
                    ? 'bg-gradient-to-r from-pink-400 to-purple-400 text-white'
                    : 'border-purple-300 text-purple-600 hover:bg-purple-50'
                }`}
              >
                <Filter className="w-4 h-4 mr-2" />
                {filter.label} ({filter.count})
              </Button>
            ))}
          </div>
        </div>

        {/* Results Count */}
        <div className="text-center mb-8 fade-in">
          <p className="text-gray-600">
            Mostrando <span className="font-semibold text-purple-600">{filteredPets.length}</span> pets
            {searchTerm && (
              <span> para "<span className="font-semibold">{searchTerm}</span>"</span>
            )}
          </p>
        </div>

        {/* Pets Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredPets.map((pet, index) => {
            const RarityIcon = pet.rarityIcon;
            return (
              <div 
                key={pet.id} 
                className="bg-white rounded-2xl shadow-lg border border-gray-100 overflow-hidden hover-lift fade-in group"
                style={{ animationDelay: `${index * 50}ms` }}
              >
                {/* Pet Image */}
                <div className="relative bg-gradient-to-br from-pink-50 to-purple-50 p-6 text-center">
                  <div className="text-5xl mb-3 group-hover:scale-110 transition-transform duration-300">
                    {pet.image}
                  </div>
                  <Badge 
                    className={`${pet.rarityColor} text-white absolute top-3 right-3 text-xs`}
                  >
                    <RarityIcon className="w-3 h-3 mr-1" />
                    {pet.rarity}
                  </Badge>
                </div>

                {/* Pet Info */}
                <div className="p-4">
                  <h3 className="text-lg font-bold text-gray-800 mb-2">{pet.name}</h3>
                  <p className="text-gray-600 text-sm mb-3 line-clamp-2">{pet.description}</p>
                  
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-xl font-bold text-pink-500">{pet.price}</span>
                    <div className="flex items-center text-yellow-400">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className="w-3 h-3 fill-current" />
                      ))}
                    </div>
                  </div>

                  <Button 
                    className="w-full bg-gradient-to-r from-pink-400 to-purple-400 hover:from-pink-500 hover:to-purple-500 text-white text-sm"
                  >
                    <Heart className="w-4 h-4 mr-2" />
                    Quero esse!
                  </Button>
                </div>
              </div>
            );
          })}
        </div>

        {/* No Results */}
        {filteredPets.length === 0 && (
          <div className="text-center py-12 fade-in">
            <div className="text-6xl mb-4">😢</div>
            <h3 className="text-2xl font-bold text-gray-800 mb-2">Nenhum pet encontrado</h3>
            <p className="text-gray-600 mb-6">
              Tente ajustar os filtros ou buscar por outro termo.
            </p>
            <Button 
              onClick={() => {
                setSelectedRarity('all');
                setSearchTerm('');
              }}
              className="bg-gradient-to-r from-pink-400 to-purple-400 hover:from-pink-500 hover:to-purple-500 text-white"
            >
              Limpar Filtros
            </Button>
          </div>
        )}
      </div>
    </section>
  );
};

export default ProductsPage;

