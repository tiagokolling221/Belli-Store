import React from 'react';
import { Heart, MessageCircle, Instagram, Twitter, Youtube, Mail } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-gradient-to-br from-purple-900 via-pink-900 to-blue-900 text-white">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Logo and Description */}
          <div className="lg:col-span-2">
            <div className="flex items-center space-x-2 mb-4">
              <div className="w-10 h-10 bg-gradient-to-br from-pink-300 to-purple-300 rounded-full flex items-center justify-center">
                <Heart className="w-6 h-6 text-white" />
              </div>
              <h3 className="logo text-2xl font-bold">Belli Store</h3>
            </div>
            <p className="text-purple-200 mb-6 max-w-md">
              A lojinha mais fofa do Roblox! Encontre os pets mais raros e especiais do Adopt Me 
              com segurança, carinho e os melhores preços. Sua coleção dos sonhos está aqui! 🐾
            </p>
            <div className="flex space-x-4">
              <a 
                href="#" 
                className="w-10 h-10 bg-white/10 rounded-full flex items-center justify-center hover:bg-white/20 transition-colors"
              >
                <Instagram className="w-5 h-5" />
              </a>
              <a 
                href="#" 
                className="w-10 h-10 bg-white/10 rounded-full flex items-center justify-center hover:bg-white/20 transition-colors"
              >
                <Twitter className="w-5 h-5" />
              </a>
              <a 
                href="#" 
                className="w-10 h-10 bg-white/10 rounded-full flex items-center justify-center hover:bg-white/20 transition-colors"
              >
                <Youtube className="w-5 h-5" />
              </a>
              <a 
                href="#" 
                className="w-10 h-10 bg-white/10 rounded-full flex items-center justify-center hover:bg-white/20 transition-colors"
              >
                <MessageCircle className="w-5 h-5" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-semibold mb-4">Links Rápidos</h4>
            <ul className="space-y-2">
              <li>
                <a href="#home" className="text-purple-200 hover:text-white transition-colors">
                  Início
                </a>
              </li>
              <li>
                <a href="#products" className="text-purple-200 hover:text-white transition-colors">
                  Produtos
                </a>
              </li>
              <li>
                <a href="#how-to-buy" className="text-purple-200 hover:text-white transition-colors">
                  Como Comprar
                </a>
              </li>
              <li>
                <a href="#contact" className="text-purple-200 hover:text-white transition-colors">
                  Contato
                </a>
              </li>
              <li>
                <a href="#" className="text-purple-200 hover:text-white transition-colors">
                  Blog
                </a>
              </li>
            </ul>
          </div>

          {/* Support */}
          <div>
            <h4 className="text-lg font-semibold mb-4">Suporte</h4>
            <ul className="space-y-2">
              <li>
                <a href="#" className="text-purple-200 hover:text-white transition-colors">
                  Central de Ajuda
                </a>
              </li>
              <li>
                <a href="#" className="text-purple-200 hover:text-white transition-colors">
                  Termos de Uso
                </a>
              </li>
              <li>
                <a href="#" className="text-purple-200 hover:text-white transition-colors">
                  Política de Privacidade
                </a>
              </li>
              <li>
                <a href="#" className="text-purple-200 hover:text-white transition-colors">
                  Trocas Seguras
                </a>
              </li>
              <li>
                <a href="#" className="text-purple-200 hover:text-white transition-colors">
                  FAQ
                </a>
              </li>
            </ul>
          </div>
        </div>

        {/* Contact Info */}
        <div className="border-t border-white/10 mt-8 pt-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
              <h4 className="text-lg font-semibold mb-4">Entre em Contato</h4>
              <div className="space-y-3">
                <div className="flex items-center space-x-3">
                  <MessageCircle className="w-5 h-5 text-purple-300" />
                  <span className="text-purple-200">Discord: BelliStore#1234</span>
                </div>
                <div className="flex items-center space-x-3">
                  <span className="w-5 h-5 text-purple-300 text-center">📱</span>
                  <span className="text-purple-200">WhatsApp: +55 (11) 99999-9999</span>
                </div>
                <div className="flex items-center space-x-3">
                  <Mail className="w-5 h-5 text-purple-300" />
                  <span className="text-purple-200">contato@bellistore.com</span>
                </div>
              </div>
            </div>
            
            <div>
              <h4 className="text-lg font-semibold mb-4">Horário de Atendimento</h4>
              <div className="space-y-2 text-purple-200">
                <p>Segunda a Sexta: 9h às 22h</p>
                <p>Sábado e Domingo: 10h às 20h</p>
                <p className="text-sm text-purple-300">
                  * Horário de Brasília (GMT-3)
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-white/10 mt-8 pt-8 text-center">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <p className="text-purple-200 text-sm">
              © 2024 Belli Store. Todos os direitos reservados. 
              <span className="text-purple-300"> Feito com </span>
              <Heart className="w-4 h-4 inline text-pink-400" />
              <span className="text-purple-300"> para a comunidade Adopt Me!</span>
            </p>
            <div className="flex items-center space-x-4 text-sm text-purple-300">
              <span>🎮 Não afiliado ao Roblox Corporation</span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;

